<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		body {
			background-image: url('gambar/hotel-horison-kendari_fb.jpg');
			background-repeat: repeat;
			font-family: sans-serif;
		}
	</style>
</head>
<body>
	<center>
		<div style="margin-top: 70px;padding: 30px;height: 200px;width: 50%; background: rgba(0,0,255,0.3);">
		<h1 style="color: red;background: yellow;">404</h1>
		<h2 style="color: yellow;background: black;">HALAMAN TIDAK DITEMUKAN</h2>
		<H3 style="color: black;background: magenta;">Kemungkinan Halaman Telah Dihapus atau <br>
		Anda Salah Menulis URL</H3>
		<a href="javascript:history.back()" style="color: blue;font-weight: bold;background: white;padding: 5px;">Kembali ke Halaman Sebelumnya</a>
		</div>
	</center>
</body>
</html>