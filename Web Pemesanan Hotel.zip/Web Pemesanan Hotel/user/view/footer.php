
	</center>	
		
	</main>
	<footer>
		<h6>Copyright &copy; 2018 | Kelompok 1</h6>
	</footer>
</body>
</html>
