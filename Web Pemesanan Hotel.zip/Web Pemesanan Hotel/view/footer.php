
	</center>	
		
	</main>
	<footer>
		<h6>Copyright &copy; 2018 | ali-inka-fahri-furkan</h6>
	</footer>
</body>
</html>
